globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/Obml03W4tlLLTFjY2f9nL/_buildManifest.js",
    "static/Obml03W4tlLLTFjY2f9nL/_ssgManifest.js",
    "static/Obml03W4tlLLTFjY2f9nL/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0ht900cau6_ur.js",
    "static/chunks/0p5.qr0b94vxo.js",
    "static/chunks/0n~dq4kpx9xxx.js",
    "static/chunks/turbopack-0agkdb7tv-786.js"
  ]
};
